package service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Ingredient;
import dao.JJYIngtDao;



public class NYSWriteProAct implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		try {
			request.setCharacterEncoding("utf-8");
			String pageNum = request.getParameter("pageNum");
			
			int ingredientNo = Integer.parseInt(request.getParameter("ingredientNo"));
			String name = request.getParameter("name");
			String grade = request.getParameter("grade");
			String danger20 = request.getParameter("danger20");
			String dangerAllergy = request.getParameter("dangerAllergy");
			String specialyType = request.getParameter("specialyType");
			String functional = request.getParameter("functional");
			
			Ingredient ingredient = new Ingredient();
			ingredient.setIngredientNo(ingredientNo);
			ingredient.setName(name);
			ingredient.setGrade(grade);
			ingredient.setDanger20(danger20);
			ingredient.setDangerAllergy(dangerAllergy);
			ingredient.setSpecialyType(specialyType);
			ingredient.setFunctional(functional);

			
			JJYIngtDao jd = JJYIngtDao.getInstance();
			int result = jd.insert(ingredient);
			
			request.setAttribute("ingredientNo", ingredientNo);
			request.setAttribute("result", result);
			request.setAttribute("pageNum", pageNum);
		} catch (Exception e) {
			System.out.println("WriteProAction error -> " + e.getMessage());
		}
		
		return "./item/NYSWritePro.jsp";
	}

}
