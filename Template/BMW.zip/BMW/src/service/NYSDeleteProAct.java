package service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.JJYIngtDao;


public class NYSDeleteProAct implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
		String pageNum = request.getParameter("pageNum");
		int ingredientNo = Integer.parseInt(request.getParameter("ingredientNo"));
		JJYIngtDao jd = JJYIngtDao.getInstance();
		int result = jd.delete(ingredientNo);
		
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("ingredientNo", ingredientNo);
		request.setAttribute("result", result);
	
		} catch (Exception e) {
			System.out.println("deleteProAction error -> " + e.getMessage());
		}
		return "./item/NYSDeletePro.jsp";
	}

}
