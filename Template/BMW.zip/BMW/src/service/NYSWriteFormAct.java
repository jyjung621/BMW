package service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Ingredient;
import dao.JJYIngtDao;

public class NYSWriteFormAct implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			int ingredientNo=0;
			String pageNum = request.getParameter("pageNum");
			if(pageNum == null) {
				pageNum = "1";
			}
			if(request.getParameter("ingredientNo") != null) {
				ingredientNo = Integer.parseInt(request.getParameter("ingredientNo"));
				JJYIngtDao jd = JJYIngtDao.getInstance();
				Ingredient ingredient = jd.select(ingredientNo);
			}
			
			request.setAttribute("ingredientNo", ingredientNo);
			request.setAttribute("pageNum", pageNum);
			
		} catch (Exception e) {
			System.out.println("WriteFormAction error -> " + e.getMessage());
		}
		
		return "./item/NYSWriteForm.jsp";
	}

}
