package service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Ingredient;
import dao.JJYIngtDao;


public class NYSUpdateProAct implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		try {
			System.out.println("00000000000000000000000000000000000000000000");
			request.setCharacterEncoding("utf-8");
			
			String pageNum = request.getParameter("pageNum");
//			int ingredientNo = Integer.parseInt(request.getParameter("ingredientNo"));
//			String name = request.getParameter("name");
//			String grade = request.getParameter("grade");
//			String danger20 = request.getParameter("danger20");
//			String dangerAllergy = request.getParameter("dangerAllergy");
//			String specialyType = request.getParameter("specialyType");
//			String functional = request.getParameter("functional");
			
			Ingredient ingt = new Ingredient();
			ingt.setIngredientNo(Integer.parseInt(request.getParameter("ingredientNo")));
			ingt.setName(request.getParameter("name"));
			ingt.setGrade(request.getParameter("grade"));
			ingt.setDanger20(request.getParameter("danger20"));
			ingt.setDangerAllergy(request.getParameter("dangerAllergy"));
			ingt.setSpecialyType(request.getParameter("specialyType"));
			ingt.setFunctional(request.getParameter("functional"));
			
			JJYIngtDao jd = JJYIngtDao.getInstance();
			int result = jd.update(ingt);
			
			request.setAttribute("result", result);
			request.setAttribute("pageNum", pageNum);
			request.setAttribute("ingredientNo", ingt.getIngredientNo());
						
		} catch (Exception e) {
			System.out.println("UpdateProAction error -> " + e.getMessage());
		}
		
		return "./item/NYSUpdatePro.jsp";
	}
}
