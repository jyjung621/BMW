package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class JJYIngtDao {
	private static JJYIngtDao instance;

	private JJYIngtDao() {
	}

	public static JJYIngtDao getInstance() {
		if (instance == null) {
			instance = new JJYIngtDao();
		}

		return instance;
	}

	private Connection getConnection() {
		Connection conn = null;
		try {
			Context ctx = new InitialContext();
			DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/OracleDB");
			conn = ds.getConnection();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return conn;
	}

	public int getTotalCnt() throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select count(*) from ingredient";
		//String sql = "insert into ingredient values (11,'제발','3','ㅁㅁ','','지성피부','자외선 차단')";
		int result = 0;

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			//result = pstmt.executeUpdate();
			rs = pstmt.executeQuery();
			if (rs.next()) {
				result = rs.getInt(1);
			}
			System.out.println("total result --> " + result);
		} catch (Exception e) {
			System.out.println("TotalCnt error -> " + e.getMessage());
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return result;
	}

	public List<Ingredient> list(int startRow, int endRow) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Ingredient> al = new ArrayList<>();
		String sql = "SELECT * FROM (SELECT ROWNUM rn, A.* FROM (SELECT * FROM ingredient ORDER BY name ) A ) where rn between ? and ?";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Ingredient ingt = new Ingredient();
//				ingt.setIngredientNo(rs.getInt("ingredientNo"));
//				ingt.setName(rs.getString("name"));
//				ingt.setGrade(rs.getString("grade"));
//				ingt.setDanger20(rs.getString("danger20"));
//				ingt.setDangerAllergy(rs.getString("dangerAllergy"));
//				ingt.setSpecialyType(rs.getString("specialyType"));
//				ingt.setFunctional(rs.getString("functional"));

				ingt.setIngredientNo(rs.getInt(2));
				ingt.setName(rs.getString(3));
				ingt.setGrade(rs.getString(4));
				ingt.setDanger20(rs.getString(5));
				ingt.setDangerAllergy(rs.getString(6));
				ingt.setSpecialyType(rs.getString(7));
				ingt.setFunctional(rs.getString(8));

				al.add(ingt);
			}

		} catch (Exception e) {
			System.out.println("list error -> " + e.getMessage());
		} finally {
			if (rs != null) {rs.close();}
			if (pstmt != null) {pstmt.close();}
			if (conn != null) {conn.close();}
		}

		return al;
	}
	
	public Ingredient select(int ingredientNo) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Ingredient ingredient = new Ingredient();
		String sql = "select * from ingredient where ingredientNo=?";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, ingredientNo);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				ingredient.setIngredientNo(rs.getInt(1)); 
				ingredient.setName(rs.getString(2)); 
				ingredient.setGrade(rs.getString(3)); 
				ingredient.setDanger20(rs.getString(4)); 
				ingredient.setDangerAllergy(rs.getString(5)); 
				ingredient.setSpecialyType(rs.getString(6)); 
				ingredient.setFunctional(rs.getString(7)); 
			}
			
			System.out.println("얍 -> " + ingredient.getIngredientNo());
			
		} catch (Exception e) {
			System.out.println("select error -> " + e.getMessage());
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (pstmt != null) {
				pstmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}

		return ingredient;
	}
	
	public int insert(Ingredient ingredient) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		int ingredientNo = ingredient.getIngredientNo();
		String sql = "insert into ingredient values (?,?,?,?,?,?,?)";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, ingredientNo);
			pstmt.setString(2, ingredient.getName());
			pstmt.setString(3, ingredient.getGrade());
			pstmt.setString(4, ingredient.getDanger20());
			pstmt.setString(5, ingredient.getDangerAllergy());
			pstmt.setString(6, ingredient.getSpecialyType());
			pstmt.setString(7, ingredient.getFunctional());
			result = pstmt.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("insert error -> " + e.getMessage());
		} finally {
			if (rs != null) {rs.close();}
			if (pstmt != null) {pstmt.close();}
			if (conn != null) {conn.close();}
		}		
		return result;
	}
	
	public int update(Ingredient ingt) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		String sql = "update ingredient set name=?, grade=?, danger20=?, dangerAllergy=?, specialyType=?, functional=? where ingredientno=?";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, ingt.getName());
			pstmt.setString(2, ingt.getGrade());
			pstmt.setString(3, ingt.getDanger20());
			pstmt.setString(4, ingt.getDangerAllergy());
			pstmt.setString(5, ingt.getSpecialyType());
			pstmt.setString(6, ingt.getFunctional());
			pstmt.setInt(7, ingt.getIngredientNo());
			result = pstmt.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("update error -> " + e.getMessage());
		} finally {
			if (pstmt != null) {pstmt.close();}
			if (conn != null) {conn.close();}
		}	
		return result;
	}
	
	
	public int delete(int ingredientNo) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		String sql = "delete from ingredient where ingredientNo=?";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, ingredientNo);
			result = pstmt.executeUpdate();
						
		} catch (Exception e) {
			System.out.println("delete error -> " + e.getMessage());
		} finally {
			if (pstmt != null) {pstmt.close();}
			if (conn != null) {conn.close();}
		}
		return result;
	}
	
	
}
