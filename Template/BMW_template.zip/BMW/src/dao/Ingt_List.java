package dao;

public class Ingt_List {
	private int itemNo;
	private int ingredientNo;

	public int getItemNo() {
		return itemNo;
	}

	public void setItemNo(int itemNo) {
		this.itemNo = itemNo;
	}

	public int getIngredIentNo() {
		return ingredientNo;
	}

	public void setIngredIentNo(int ingredientNo) {
		this.ingredientNo = ingredientNo;
	}

}
